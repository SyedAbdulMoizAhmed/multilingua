import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';

const app = express();
app.use(cors());
app.use(express.json());

const HUGGINGFACE_API_TOKEN = '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';

const translate = async (text, model) => {
  const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${HUGGINGFACE_API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ inputs: text })
  });

  const result = await response.json();
  return result[0]?.translation_text || 'Translation failed';
};

app.post('/translate', async (req, res) => {
  const { text, from, to } = req.body;
  let model;

  if (from === 'en' && to === 'ar') model = 'Helsinki-NLP/opus-mt-en-ar';
  else if (from === 'ar' && to === 'en') model = 'Helsinki-NLP/opus-mt-ar-en';
  else return res.status(400).json({ error: 'Unsupported language pair' });

  try {
    const translation = await translate(text, model);
    res.json({ translation });
  } catch (err) {
    res.status(500).json({ error: 'Translation failed' });
  }
});

app.listen(3000, () => console.log("API running on http://localhost:3000"));